export interface SingleObstacles {
	sX: number;
	sY: number;
	sWidth: number;
	sHeight: number;
	width: number;
	height: number;
}
