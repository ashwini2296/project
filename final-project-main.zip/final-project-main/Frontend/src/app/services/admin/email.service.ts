import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class EmailService {
  constructor(private httpreq: HttpClient) {}

  sendMessage(body: { email: any; score: any }) {
    return this.httpreq.post('http://localhost:8080/api/email', body);
  }
}
