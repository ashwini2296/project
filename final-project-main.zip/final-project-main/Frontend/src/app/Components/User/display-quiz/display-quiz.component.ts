import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  OnDestroy,
} from '@angular/core';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { correctAnswers } from 'src/app/Class/answer';
import { Question } from 'src/app/Class/question';
import { State } from 'src/app/Class/state';
import { QuizStateService } from 'src/app/services/admin/quiz-state.service';
import { VerifyAnswerService } from 'src/app/services/admin/verify-answer.service';
import { QuestionsService } from 'src/app/services/user/questions.service';
import { ScoreService } from 'src/app/services/admin/score.service';
import { Score } from 'src/app/Class/score';
import { AddQuizService } from 'src/app/services/admin/add-quiz.service';
import { CountdownComponent } from 'ngx-countdown';
import { EmailService } from 'src/app/services/admin/email.service';

@Component({
  selector: 'app-display-quiz',
  templateUrl: './display-quiz.component.html',
  styleUrls: ['./display-quiz.component.scss'],
})
export class DisplayQuizComponent implements OnInit, OnDestroy {
  score: number = 0;
  questions = new Question();
  answerArray: correctAnswers[] = [];
  list: any = [];
  typeName: any;
  questionId: any;
  quizId: any;
  categoryId: any;
  QuestionList: any;
  counter = 1800;
  tick = 1000;
  tempScore: any;
  ans: any;
  correctans: any;
  a: string;
  timer: any;
  newTimer: any;
  seconds: number = 0;
  qnProgress: number = 0;
  id: any;
  showStop: boolean;
  state: any[];
  userId: any = sessionStorage.getItem('userId');
  duration: any;
  newTime: any;
  reamaingTime: any;
  newRTime: any;
  todayString: string = new Date().toDateString();
  @ViewChild('cd1', { static: false }) private cd1: CountdownComponent;
  constructor(
    private r: Router,
    private service: QuestionsService,
    private verifyAnswerService: VerifyAnswerService,
    private route: ActivatedRoute,
    private quizStateService: QuizStateService,
    private scoreService: ScoreService,
    private addQuizService: AddQuizService,
    private emailService: EmailService
  ) {
    this.route.paramMap.subscribe((p: ParamMap) => {
      this.quizId = p.get('id');
      this.storeQuizId(this.quizId);
    });
    this.getQuestion(this.quizId);
    this.getTimer();
  }

  ngOnInit(): void {
    this.getPrevStateAnswer();
    this.verifyAnswerService.getScore(this.userId).subscribe((data) => {
      this.tempScore = data;
      this.score = this.tempScore[0].score;
    });
    this.getRemainingTime();
  }
  getTimer() {
    this.addQuizService.getDuration(this.newQuizId).subscribe((data) => {
      this.duration = data;
      this.timer = this.duration[0].duration;
      this.reamaingTime = this.timer;
    });
  }
  interval: any;
  getRemainingTime() {
    this.interval = setInterval(() => {
      this.reamaingTime = this.reamaingTime - 3;
      this.quizStateService
        .updateTime(this.reamaingTime, this.userId, this.newQuizId)
        .subscribe(() => {});
    }, 3000);
  }

  stateData: any = [];
  storeQuizId(id: any) {
    this.newQuizId = id;
    sessionStorage.setItem('quizId', this.newQuizId);
  }
  getPrevStateAnswer() {
    this.quizStateService.getState(this.userId).subscribe((data) => {
      let state = Object.values(data);
      if (typeof this.state !== undefined) {
        for (var i = 0; i < this.QuestionList.length; i++) {
          for (var j = 0; j < state.length; j++) {
            if (this.QuestionList[i].questionId == state[j].questionId) {
              this.QuestionList[i].found = true;
              this.QuestionList[i].selectedOption = state[j].answer;
            }
          }
        }
        this.timer = state[0].reamainingTime;
        this.reamaingTime = this.timer;
      }
    });
  }

  ngOnDestroy() {}

  getQuestion(quizId: number) {
    this.categoryId = sessionStorage.getItem('categoryId');
    return this.service
      .displayQuestion(quizId, this.categoryId)
      .subscribe((data) => {
        this.QuestionList = data;
        Object.keys(this.QuestionList).map((ele) => {
          this.QuestionList[ele] = {
            ...this.QuestionList[ele],
            found: null,
            selectedOption: null,
            CorrectOption: null,
            Time: null,
          };
        });

        sessionStorage.removeItem('categoryId');
      });
  }
  found: boolean;
  queId: number;
  cans: any;
  flag: boolean = true;
  queId1: any;
  result: any;
  newQuizId: any;

  question(Qid: any, Aid: any, index: any) {
    this.queId1 = Qid;
    this.result = Aid;
    var obj = new correctAnswers(Qid, Aid);
    const state = new State(
      Aid,
      this.userId,
      Qid,
      this.newQuizId,
      this.reamaingTime
    );

    this.quizStateService.addState(state).subscribe((state) => {});

    if (this.answerArray.length == 0) {
      this.answerArray.push(obj);
    } else {
      for (let i = 0; i < this.answerArray.length; i++) {
        if (this.answerArray[i].id === Qid) {
          this.answerArray[i].userAnswer = obj.userAnswer;
          this.flag = false;
          break;
        }
      }
      if (this.flag == true) {
        this.answerArray.push(obj);
      }
    }

    return this.verifyAnswerService.verifyAnswer(Qid).subscribe((data) => {
      this.ans = data;
      this.verifyAnswerService.answer = data;
      this.a = this.ans[0].answer;
      this.QuestionList[index] = {
        ...this.QuestionList[index],
        found: true,
        selectedOption: Aid,
        CorrectOption: this.a,
      };

      if (Aid === this.ans[0].answer) {
        this.score = this.score + 1;

        this.flag = false;
      } else {
      }
    });
  }
  userEmail = sessionStorage.getItem('userEmail');
  sendMail() {
    let reqObj = {
      email: this.userEmail,
      score: this.score,
    };
    this.emailService.sendMessage(reqObj).subscribe((data: any) => {});
  }
  onSubmit() {
    let currDate = new Date().toISOString().slice(0, 10);
    const score = new Score(this.userId, this.newQuizId, this.score, currDate);
    this.scoreService.addScore(score).subscribe((score) => {});
    this.r.navigate(['/result']);
  }
}
