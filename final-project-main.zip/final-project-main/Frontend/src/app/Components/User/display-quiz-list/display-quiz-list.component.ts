import { Component, OnInit } from '@angular/core';
import { ParamMap, ActivatedRoute, Router } from '@angular/router';
import { QuizService } from 'src/app/services/user/quiz.service';
import { AddFavouriteService } from 'src/app/services/user/add-favourite.service';

@Component({
  selector: 'app-display-quiz-list',
  templateUrl: './display-quiz-list.component.html',
  styleUrls: ['./display-quiz-list.component.scss'],
})
export class DisplayQuizListComponent implements OnInit {
  id1: any;
  quizList: any;
  favList: any = [];
  constructor(
    private route: ActivatedRoute,
    private service: QuizService,
    private service1: AddFavouriteService
  ) {
    this.route.paramMap.subscribe((p: ParamMap) => {
      this.id1 = p.get('id');
      sessionStorage.setItem('categoryId', this.id1);
      this.getQuizByCategory(this.id1);
    });
  }

  ngOnInit(): void {
    this.service1.getFavList().subscribe((data) => {
      this.favList = data;
    });
  }

  getQuizByCategory(id: number) {
    return this.service.displayQuizByCategory(this.id1).subscribe((que) => {
      this.quizList = que;
    });
  }

  addToFav(q: any) {
    var fav = document.getElementById(q);
    if (fav != null) {
      fav.classList.add('remove');
    }
    var list: any;
    if (fav != null) {
      list = fav.classList;

      for (let i = 0; i < list.length; i++) {
        if (list[i] == 'change') {
          fav.classList.remove('change');
          fav.classList.add('remove');
          this.service1.deleteFavQuiz(q).subscribe();
          break;
        }
        if (list[i] == 'remove') {
          fav.classList.remove('remove');
          fav.classList.add('change');
          this.service1.postFavQuiz(q).subscribe();
          break;
        }
      }
    }
  }
  count: any;
  newCount: any;
  nQuizId: any;
  updateCount(QuizId: any) {
    this.service.getClickCount(QuizId).subscribe((data) => {
      this.count = data;
      this.newCount = this.count[0].click_count + 1;
      this.nQuizId = QuizId;
      this.service
        .updateClickCount(this.newCount, this.nQuizId)
        .subscribe(() => {});
    });
  }
}
