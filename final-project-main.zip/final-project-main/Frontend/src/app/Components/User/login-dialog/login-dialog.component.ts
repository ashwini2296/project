import { Component, OnInit } from '@angular/core';
import { RegisterService } from 'src/app/services/user/register.service';
import { EncrdecrService } from 'src/app/services/admin/encrdecr.service';
import { Users } from '../register/Users';
import { Router } from '@angular/router';
import {
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
  MatSnackBar,
} from '@angular/material/snack-bar';
@Component({
  selector: 'app-login-dialog',
  templateUrl: './login-dialog.component.html',
  styleUrls: ['./login-dialog.component.scss'],
})
export class LoginDialogComponent implements OnInit {
  flag: boolean = false;
  usr = new Users();
  usrList: any;
  logEmail: string = '';
  logPassword: string = '';
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  constructor(
    private r: Router,
    private sObj: RegisterService,
    private EncrDecr: EncrdecrService,
    private _snackBar: MatSnackBar
  ) {}

  ngOnInit() {}
  login() {
    this.sObj.getUsers().subscribe((data) => {
      this.usrList = data;
      for (let i = 0; i < this.usrList.length; i++) {
        if (
          this.logEmail == this.usrList[i].email &&
          this.logPassword == this.EncrDecr.get(this.usrList[i].password)
        ) {
          this.flag = true;
          sessionStorage.setItem('userId', this.usrList[i].userId);
          sessionStorage.setItem('userName', this.usrList[i].userName);
          sessionStorage.setItem('userEmail', this.usrList[i].email);
          if (this.usrList[i].role == 'User') {
            this._snackBar.open('Login successful ', ' ', {
              duration: 2000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
            this.r.navigate(['/home']);
          } else {
            this._snackBar.open('Login successful ', ' ', {
              duration: 2000,
              horizontalPosition: this.horizontalPosition,
              verticalPosition: this.verticalPosition,
            });
            this.r.navigate(['/admin']);
          }
        }
      }
      if (this.flag == false) {
        this._snackBar.open(
          'Login failed please check email or password',
          ' ',
          {
            duration: 2000,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
          }
        );
      }
    });
  }
  signup() {
    this.usr.signUpPassword1 = this.EncrDecr.set(
      this.usr.signUpEmail,
      this.usr.signUpPassword1
    );

    this.sObj.postUser(this.usr).subscribe((data) => {});

    this._snackBar.open('Login Done ... ', ' ', {
      duration: 2000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });

    this.r.navigate(['/home']);
  }
}
