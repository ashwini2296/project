import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ResultComponent } from './result.component';
import { VerifyAnswerService } from 'src/app/services/admin/verify-answer.service';
import { QuizStateService } from 'src/app/services/admin/quiz-state.service';
import { ScoreService } from 'src/app/services/admin/score.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

fdescribe('HomeComponent', () => {
  let component: ResultComponent;
  let fixture: ComponentFixture<ResultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ResultComponent],
      imports: [HttpClientModule, RouterTestingModule],
      providers: [VerifyAnswerService, QuizStateService, ScoreService],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should define score ', () => {
    //expect(component.result).toBeDefined();
    expect(component.nscore).toBeDefined();

    expect(component.nscore).toBeGreaterThanOrEqual(0);
  });
});
