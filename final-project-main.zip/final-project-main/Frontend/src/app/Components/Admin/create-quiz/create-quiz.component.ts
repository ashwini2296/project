import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { AddCategoryService } from 'src/app/services/admin/add-category.service';
import { QuizService } from 'src/app/services/user/quiz.service';

@Component({
  selector: 'app-create-quiz',
  templateUrl: './create-quiz.component.html',
  styleUrls: ['./create-quiz.component.scss'],
})
export class CreateQuizComponent implements OnInit {
  categoryName: any;
  Quiz = {
    quizName: '',
    categoryId: '',
    duration: '',
    count: '',
  };
  constructor(
    private route: Router,
    private service: AddCategoryService,
    private http: HttpClient
  ) {
    this.service.getCategoriess().subscribe((data) => {
      this.categoryName = data;
    });
  }

  ngOnInit(): void {}

  public selectedFile: any;

  fileUpload(event: any) {
    this.selectedFile = event.target.files[0];
  }
  fileUploadHandler(event: any) {
    event.preventDefault();

    const data: FormData = new FormData();
    data.append('uploadfile', this.selectedFile);
    data.append('quizName', this.Quiz.quizName);
    data.append('duration', this.Quiz.duration);
    data.append('categoryId', this.Quiz.categoryId);
    data.append('count', this.Quiz.count);

    console.log(data);

    this.http
      .post('http://localhost:8080/api/quiz/image', data)
      .subscribe((res: any) => {
        if (res['status'] === 200) {
        }
      });
    this.route.navigate(['admin/quizList']);
  }
}
