import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-new-quiz',
  templateUrl: './create-new-quiz.component.html',
  styleUrls: ['./create-new-quiz.component.scss']
})
export class CreateNewQuizComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
