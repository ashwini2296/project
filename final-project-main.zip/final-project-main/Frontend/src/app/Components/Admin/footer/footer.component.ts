import { Component, OnInit } from '@angular/core';
import { FeedbackService } from 'src/app/services/admin/feedback.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent implements OnInit {
  constructor(private service: FeedbackService) {}

  ngOnInit(): void {}

  bad() {
    this.service.deleteFeedback().subscribe();
    this.service.postFeedback('bad').subscribe();
  }

  moderate() {
    this.service.deleteFeedback().subscribe();
    this.service.postFeedback('moderate').subscribe();
  }
  good() {
    this.service.deleteFeedback().subscribe();
    this.service.postFeedback('good').subscribe();
  }
  goup() {
    window.scrollTo(0, 0);
  }
}
