module.exports = (app) => {
  const games = require("../controllers/game.controller.js");
  const upload = require("../config/upload.config.js");
  var router = require("express").Router();
  router.get("/byId/:gameId", games.getGameById);
  router.get("/", games.getTopScore);
  router.get("/prev", games.getGamePrevScore);
  router.get("/allGames", games.getAllGames);
  router.post("/", upload.single("uploadfile"), games.insertGames);
  app.use("/api/game", router);
};
