module.exports = (app) => {
  const quiz = require("../controllers/quiz.controller.js");
  const upload = require("../config/upload.config.js");
  var router = require("express").Router();

  router.post("/image", upload.single("uploadfile"), quiz.insertQuiz);
  router.get("/getQuizName/:catname", quiz.getQuizNames);
  router.post("/addQuestion", quiz.addQuestion);
  router.get("/getCategoryName", quiz.getCategoryName);
  router.get("/getTypeName", quiz.getTypeName);
  router.get("/getQuiz/names", quiz.getQuiz);
  router.get("/getQuiz/byname/:quizName", quiz.getQuizNameByName);
  router.get("/byId/:id", quiz.getQuizNameById);
  router.post("/", quiz.insert);
  app.use("/api/quiz", router);
};
