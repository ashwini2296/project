const db = require("../models");
const fs = require("fs");
exports.getGameById = (req, res) => {
  db.sequelize
    .query("select * from game where gameId=?", {
      replacements: [req.params.gameId],
      type: db.sequelize.QueryTypes.SELECT,
    })
    .then((data) => {
      res.send(data);
    });
};

exports.getGamePrevScore = (req, res) => {
  db.sequelize
    .query(
      "select g.gameName, s.score from game g ,scoreboard s where g.gameId = s.gameId and s.userId=? and s.gameId=?;",
      {
        replacements: [req.query.userId, req.query.gameId],
        type: db.sequelize.QueryTypes.SELECT,
      }
    )
    .then((data) => {
      res.send(data);
    });
};

exports.getTopScore = (req, res) => {
  db.sequelize
    .query(
      "select g.gameName,u.name,s.score from game g,users u,scoreboard s where g.gameId=s.gameId and u.userId=s.userId and s.game_date=(select DATE_FORMAT(now(),'%y-%m-%d')) order by s.score desc limit 5",
      {
        type: db.sequelize.QueryTypes.SELECT,
      }
    )
    .then((data) => {
      res.send(data);
    });
};

exports.getAllGames = (req, res) => {
  db.sequelize
    .query("select * from game", { type: db.sequelize.QueryTypes.SELECT })
    .then((data) => {
      res.send(data);
    });
};

const Image = db.game;
exports.insertGames = (req, res) => {
  Image.create({
    type: req.file.mimetype,
    name: req.file.originalname,
    data: fs.readFileSync(
      "D:/Dipali-BT-main/Frontend/src/" + "assets/category/" + req.file.filename
    ),
    gameName: req.body.gameName,
  }).then((image) => {
    try {
      fs.writeFileSync(
        "D:/Dipali-BT-main/Frontend/src/" + "assets/category/" + image.name,
        image.data
      );

      // exit node.js app
      res.json({ msg: "File uploaded successfully!", file: req.file });
    } catch (e) {
      res.json({ err: e });
    }
  });
};
