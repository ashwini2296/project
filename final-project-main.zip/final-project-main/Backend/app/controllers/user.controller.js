const db = require("../models");
exports.insert=(req,res)=>{
  
  db.sequelize.query("insert into users (email,password,name,role) values(?,?,?,?)",
  {replacements: [ req.body.signUpEmail,req.body.signUpPassword1,req.body.signUpName,"User"],type: db.sequelize.QueryTypes.INSERT }).then(data=>{
      res.send(data);  
    });
}

exports.getUserData = (req,res)=>{
  db.sequelize.query("select * from users",{type: db.sequelize.QueryTypes.SELECT }).then(data=>{
      res.send(data);
    });
}

exports.getUserById=(req,res)=>{
  db.sequelize.query("select * from users where userId=?",
  {replacements:[req.params.userId],type: db.sequelize.QueryTypes.SELECT }).then(data=>{
    res.send(data);
  })
}