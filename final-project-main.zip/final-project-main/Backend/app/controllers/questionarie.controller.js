const db = require("../models");
exports.getQuestions = (req,res)=>{
    db.sequelize.query("select * from questionarie where quizId=? ORDER BY RAND() LIMIT 10 ",{replacements: [ req.params.quizId],type: db.sequelize.QueryTypes.SELECT }).then(data=>{
        res.send(data);
      });
  }