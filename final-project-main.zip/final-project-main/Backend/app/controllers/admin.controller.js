const db = require("../models");

exports.getUsersForQuiz = (req, res) => {
  db.sequelize
    .query(
      "select DISTINCT(q.quizName),u.name from quiz q,users u,scoreboard s where s.userId=u.userId and s.game_date=(select DATE_FORMAT(now(),'%y-%m-%d')) ",
      { type: db.sequelize.QueryTypes.SELECT }
    )
    .then((data) => {
      res.send(data);
    });
};

exports.getTopScorers = (req, res) => {
  db.sequelize
    .query(
      "select u.name,q.quizName,s.score from users u,scoreboard s,quiz q where s.userId=u.userId and q.quizId=s.quizId and s.game_date=(select DATE_FORMAT(now(),'%y-%m-%d')) order by s.score desc limit 5",
      { type: db.sequelize.QueryTypes.SELECT }
    )
    .then((data) => {
      res.send(data);
    });
};

exports.updateClickCount = (req, res) => {
  db.sequelize
    .query("update quiz set click_count=? where quizId=?", {
      replacements: [req.body.click_count, req.body.quizId],
      type: db.sequelize.QueryTypes.PUT,
    })
    .then((data) => {
      res.send(data);
    });
};
exports.getClickCount = (req, res) => {
  db.sequelize
    .query("select click_count,quizName from quiz where quizId=?", {
      replacements: [req.params.quizId],
      type: db.sequelize.QueryTypes.SELECT,
    })
    .then((data) => {
      res.send(data);
    });
};

exports.getClickCountOfGame = (req, res) => {
  db.sequelize
    .query("select click_count,gameName from game where gameId=?", {
      replacements: [req.params.gameId],
      type: db.sequelize.QueryTypes.SELECT,
    })
    .then((data) => {
      res.send(data);
    });
};

exports.updateClickCountofGame = (req, res) => {
  db.sequelize
    .query("update game set click_count=? where gameId=?", {
      replacements: [req.body.click_count, req.body.gameId],
      type: db.sequelize.QueryTypes.PUT,
    })
    .then((data) => {
      res.send(data);
    });
};
